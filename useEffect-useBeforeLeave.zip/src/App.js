import React, { useRef, useEffect, useState } from "react";
import ReactDOM from "react-dom";

const useBeforeLeave = (onBefore) => {
  if (typeof onBefore !== "function") return;
  const handle = (event) => {
    const { clientY } = event;
    if (clientY <= 0) {
      onBefore();
    }
  };
  useEffect(() => {
    document.addEventListener("mouseleave", handle);
    return () => document.removeEventListener("mouseleave", handle);
  }, []);
};
export default function App() {
  const askMention = () => console.log("will you leave?");
  useBeforeLeave(askMention);
  return (
    <div className="App">
      <h1>hello</h1>
    </div>
  );
}
