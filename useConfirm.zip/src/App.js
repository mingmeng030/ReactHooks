import React, { useEffect, useState, useRef } from "react";
import ReactDOM from "react-dom";
import "./styles.css";

//사용자가 무언가를 하기전에 확인하는 것으로
//사용자가 버튼을 click하면 event 실행 전 msg를 보여준다.
const useConfirm = (message = "", callback, rejection) => {
  if (typeof callback !== "function") return;
  const confirmAction = () => {
    if (confirm(message)) callback();
    else rejection();
  };
  return confirmAction;
};
export default function App() {
  const deleteMsg = () => console.log("Delete button has clicked");
  const abort = () => console.log("Aborted");
  const confirmDelete = useConfirm("Are you sure?", deleteMsg, abort);
  return (
    <div className="App">
      <button onClick={confirmDelete}>Delete</button>
    </div>
  );
}
