import React, { useState } from "react";
import ReactDOM from "react-dom";
import "./styles.css";

const content = [
  {
    tab: "Romnace and Musical",
    content: "I think you like SingStreet, LaLaLand, The Greatest Show!"
  },
  {
    tab: "Fantasy",
    content: "Avengers, Harry Potter, The Lord of the Rings!"
  }
];
const useTabs = (initialTab, tabArray) => {
  if (!tabArray || !Array.isArray(tabArray)) return;
  const [currentIndex, setCurrentIndex] = useState(initialTab);
  return {
    // content배열의 currentIndex번 째 요소와 setCurrentIndex 함수를
    // 각각 setCurrentIndex, changeItem의 변수에 저장하여 return 한다.
    currentItem: tabArray[currentIndex],
    changeItem: setCurrentIndex
  };
};
export default function App() {
  //useTabs 함수의 return 값을 가져온다.(currentItem와 changeItem이름 그대로 가져와야함)
  const { currentItem, changeItem } = useTabs(0, content);
  return (
    <div className="App">
      <h1>Which genre do you prefer more?</h1>
      {/* tab과 content가 들어있는 content를 map으로 순회하며
          각 content의 요소와 index를 각각 genreTab와 genreIndex로 간주한다.
      */}
      {content.map((genreTab, genreIndex) => (
        //button이 click되면 해당 genreTab의 genreIndex 이용해 현재 index를 변경한다.
        <button onClick={() => changeItem(genreIndex)}>{genreTab.tab}</button>
      ))}
      {/* currentItem의 content 보여주기 */}
      <div>{currentItem.content}</div>
    </div>
  );
}
