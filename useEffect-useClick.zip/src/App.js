import React, { useEffect, useState, useRef } from "react";
import ReactDOM from "react-dom";
import "./styles.css";

const useClick = (onClick) => {
  if (typeof onClick !== "function") return;
  const element = useRef();
  useEffect(() => {
    if (element.current) element.current.addEventListener("click", onClick);
    return () => {
      if (element.current)
        element.current.removeEventListener("click", onClick);
    };
  }, []);
  return element;
};
export default function App() {
  const SayHello = () => console.log("say hello");
  const focusInput = useRef();
  const title = useClick(SayHello);
  setTimeout(() => focusInput.current.focus(), 3000);
  return (
    <div className="App">
      <h1 ref={title}>hi</h1>
      <input ref={focusInput} placeholder="write here" />
    </div>
  );
}
